# Pazaryeri — başlangıç paketi

Bu depo, özgün çok satıcılı pazaryeri projesinin **ilk arayüz ve dağıtım iskeletidir**.

## İçerik

- Next.js tabanlı müşteri ana sayfası
- Yönetici paneli görsel taslağı: `/admin`
- Satıcı paneli görsel taslağı: `/seller`
- Dockerfile ve Docker Compose
- PostgreSQL servisi (henüz uygulama modellerine bağlanmış değildir)

## Önemli

Bu sürüm **üretime hazır bir e-ticaret sistemi değildir**. Görünen ürünler, istatistikler ve satıcı bilgileri örnektir. Henüz gerçek üyelik, veritabanı CRUD işlemleri, sepet, sipariş, ödeme, kargo veya rol tabanlı erişim uygulanmamıştır. Gerçek ödeme bilgisi girmeyin ve bu arayüzü tek başına canlı satış için kullanmayın.

## Gereksinimler

- Docker Engine
- Docker Compose eklentisi
- Git (GitHub üzerinden çekmek için)

## İlk kurulum

1. `.env.example` dosyasını `.env` olarak kopyalayın.
2. `.env` içindeki `POSTGRES_PASSWORD` değerini uzun ve rastgele bir parola ile değiştirin.
3. `DATABASE_URL` içindeki parolayı aynı değerle eşleştirin.
4. `next.config.ts` dosyasına `output: "standalone"` ekleyin (Dockerfile bunu kullanır).
5. Çalıştırın:

```bash
docker compose up -d --build
docker compose ps
docker compose logs -f app
```

Uygulama sunucuda yalnızca `127.0.0.1:3000` adresine bağlanır. Nginx üzerinden alan adına yönlendirme ayrıca yapılandırılmalıdır. PostgreSQL portu internete açılmaz.

## Sonraki geliştirme aşamaları

1. Next.js standalone yapılandırmasını doğrulama ve sürüm sabitleme
2. Prisma ve veritabanı şeması
3. Güvenli kimlik doğrulama ve roller
4. Gerçek kategori/ilan CRUD işlemleri
5. Sepet ve sipariş akışı
6. Ödeme sağlayıcısı test ortamı
7. Satıcı, kargo, iade ve denetim kayıtları
8. Güvenlik, yedekleme ve kabul testleri
