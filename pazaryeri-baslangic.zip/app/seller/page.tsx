export default function SellerPage() {
  return <main className="wrap" style={{paddingTop:28,paddingBottom:70}}>
    <a className="logo" href="/">pazar<span>•</span></a>
    <div className="section-head" style={{marginTop:34}}><div><h2>Satıcı merkezine hoş geldin</h2><p>İlanlarını ve siparişlerini tek yerden yönet.</p></div><span className="condition">ÖN İZLEME</span></div>
    <div className="notice"><strong>Satıcı paneli taslağı:</strong> Bu sayfa şu an yalnızca arayüz örneğidir. Üyelik, gerçek ilan kaydı, siparişler ve ödeme bakiyesi henüz etkin değildir.</div>
    <div className="stat-grid" style={{marginTop:18}}>{[["Aktif ilan","0"],["Bekleyen sipariş","0"],["Toplam satış","₺0"],["Mağaza puanı","—"]].map(([a,b])=><div className="stat" key={a}><div className="stat-label">{a}</div><div className="stat-value">{b}</div><div className="stat-note">Sistem bağlantısı bekleniyor</div></div>)}</div>
    <section className="panel"><h2>Satışa başlamak için</h2><p style={{color:"var(--muted)",fontSize:13,lineHeight:1.8}}>Hesap oluşturma ve doğrulama → Satıcı profili → İlan oluşturma → Moderasyon → Sipariş ve kargo yönetimi.</p><a className="cta" href="/">Mağazaya dön →</a></section>
  </main>;
}