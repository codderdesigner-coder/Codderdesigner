const categories = [
  ["📱", "Elektronik"], ["👟", "Moda"], ["🛋️", "Ev & yaşam"],
  ["🎮", "Oyun & hobi"], ["🚲", "Spor & outdoor"], ["✨", "Diğer"],
];
const products = [
  { icon: "🎧", tag: "ÖNE ÇIKAN", title: "Kablosuz kulaklık — premium ses", seller: "TeknoDükkan", price: "₺2.499", condition: "Yeni" },
  { icon: "👟", tag: "YENİ İLAN", title: "Günlük sneaker, rahat ve hafif", seller: "urban.store", price: "₺1.850", condition: "Çok iyi" },
  { icon: "📷", tag: "FIRSAT", title: "Kompakt fotoğraf makinesi", seller: "Lens Dünyası", price: "₺6.750", condition: "İyi" },
  { icon: "⌚", tag: "YENİ İLAN", title: "Minimal tasarımlı akıllı saat", seller: "Zaman Atölyesi", price: "₺3.299", condition: "Yeni" },
];
export default function Home() {
  return (
    <>
      <div className="topline">Yeni nesil alışveriş deneyimine hoş geldin · Keşfet, karşılaştır, güvenle alışveriş yap</div>
      <header className="header">
        <div className="wrap header-inner">
          <a className="logo" href="/">pazar<span>•</span></a>
          <label className="search"><span>⌕</span><input placeholder="Ne arıyorsun? Ürün, marka veya kategori..." /></label>
          <nav className="nav-actions"><a className="optional" href="/admin">Yönetim</a><a className="optional" href="/seller">Satış yap</a><a href="/seller">♡</a><a className="pill" href="/seller">Hesabım ↗</a></nav>
        </div>
      </header>
      <main className="wrap">
        <nav className="category-nav"><a href="#kategoriler">Kategoriler</a><a href="#urunler">Öne çıkanlar</a><a href="#urunler">Yeni ilanlar</a><a href="#guven">Güvenli alışveriş</a><a href="/seller">Satış yap</a></nav>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow">✳ Yeni nesil pazaryeri</span>
            <h1>Aradığın şey,<br/>iyi bir yerde.</h1>
            <p>Sevdiğin ürünleri keşfet. İhtiyacını kolayca bul. Alışverişin yeni hâliyle tanış.</p>
            <a className="cta" href="#urunler">Ürünleri keşfet <span>→</span></a>
          </div>
          <div className="hero-art"><div className="orb">🛍️</div><div className="float-card">✦ Her gün yeni keşifler</div></div>
        </section>
        <section id="kategoriler">
          <div className="section-head"><div><h2>Kategorileri keşfet</h2><p>Aradığın dünyaya tek dokunuşla ulaş.</p></div><a className="text-link" href="#urunler">Tümünü gör →</a></div>
          <div className="category-grid">{categories.map(([icon, name]) => <a className="category-card" href="#urunler" key={name}><span className="category-icon">{icon}</span><strong>{name}</strong></a>)}</div>
        </section>
        <section id="urunler">
          <div className="section-head"><div><h2>Senin için seçtiklerimiz</h2><p>Keşfetmeye değer ürünler ve yeni ilanlar.</p></div><a className="text-link" href="#urunler">Daha fazlası →</a></div>
          <div className="products">{products.map((p) => <article className="product" key={p.title}><div className="product-visual"><span className="badge">{p.tag}</span><button className="heart" aria-label="Favorilere ekle">♡</button><span>{p.icon}</span></div><div className="product-info"><div className="product-title">{p.title}</div><div className="seller">Satıcı: {p.seller}</div><div className="price-row"><strong className="price">{p.price}</strong><span className="condition">{p.condition}</span></div></div></article>)}</div>
        </section>
        <section className="trust-strip" id="guven">
          <div className="trust"><span className="trust-icon">🛡️</span><div><strong>Güven odaklı deneyim</strong><small>Şeffaf ve kontrollü alışveriş için tasarlandı.</small></div></div>
          <div className="trust"><span className="trust-icon">⚡</span><div><strong>Kolay keşif</strong><small>Aradığını daha az adımda bul.</small></div></div>
          <div className="trust"><span className="trust-icon">🤝</span><div><strong>Alıcı ve satıcı bir arada</strong><small>Alışveriş ve satış tek platformda.</small></div></div>
        </section>
      </main>
      <footer className="footer"><div className="wrap footer-inner"><div><a className="logo" href="/">pazar<span>•</span></a><p>Alışverişin yeni hâli. Bu proje başlangıç tasarımıdır.</p></div><div><a href="/admin">Yönetici paneli taslağı</a>　·　<a href="/seller">Satıcı paneli taslağı</a></div></div></footer>
    </>
  );
}