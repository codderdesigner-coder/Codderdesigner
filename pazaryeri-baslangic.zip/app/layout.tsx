import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pazar — Yeni nesil alışveriş",
  description: "Özgün pazaryeri projemizin başlangıç sürümü.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}