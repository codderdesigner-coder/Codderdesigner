const stats = [
  ["Toplam kullanıcı", "12.840", "↑ Örnek gösterge"],
  ["Yayındaki ilan", "3.264", "↑ Örnek gösterge"],
  ["Sipariş", "1.092", "↑ Örnek gösterge"],
  ["Brüt satış hacmi", "₺842.560", "↑ Örnek gösterge"],
];
const listings = [
  ["#PR-1048", "Kablosuz kulaklık", "TeknoDükkan", "Onay bekliyor"],
  ["#PR-1047", "Deri günlük çanta", "urban.store", "Yayında"],
  ["#PR-1046", "Kompakt fotoğraf makinesi", "Lens Dünyası", "İnceleniyor"],
  ["#PR-1045", "Akıllı saat", "Zaman Atölyesi", "Yayında"],
];
export default function AdminPage() {
  return <div className="admin-shell">
    <aside className="sidebar"><a className="logo" href="/">pazar<span>•</span></a><div className="side-label">Genel</div><nav className="side-nav"><a className="side-link active" href="/admin">▦　Dashboard</a><a className="side-link" href="#ilanlar">▤　İlan yönetimi</a><a className="side-link" href="#kullanicilar">♙　Kullanıcılar</a><a className="side-link" href="#siparisler">▣　Siparişler</a><a className="side-link" href="#ayarlar">⚙　Ayarlar</a></nav><div className="side-label">Platform</div><a className="side-link" href="/">↗　Mağazayı görüntüle</a></aside>
    <main className="admin-main">
      <div className="admin-top"><div><h1>Genel bakış</h1><p>Platformunun nabzı, tek ekranda.</p></div><div className="admin-user">Yönetici alanı · Demo</div></div>
      <div className="notice"><strong>Demo arayüzü:</strong> Bu ekrandaki sayılar örnektir. Henüz gerçek kullanıcı, ilan veya sipariş verisine bağlı değildir. Gerçek admin işlemleri için kimlik doğrulama, yetkilendirme ve veritabanı bağlantısı sonraki geliştirme adımlarında kurulmalıdır.</div>
      <div className="stat-grid" style={{marginTop:18}}>{stats.map(([label,value,note])=><div className="stat" key={label}><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>)}</div>
      <section className="panel" id="ilanlar"><h2>Son ilanlar</h2><div className="table-wrap"><table><thead><tr><th>İlan no</th><th>İlan</th><th>Satıcı</th><th>Durum</th></tr></thead><tbody>{listings.map(([id,title,seller,status])=><tr key={id}><td>{id}</td><td><strong>{title}</strong></td><td>{seller}</td><td><span className="status">{status}</span></td></tr>)}</tbody></table></div></section>
      <section className="panel" id="siparisler"><h2>Yönetim modülleri</h2><p style={{color:"var(--muted)",fontSize:13,lineHeight:1.8,margin:0}}>Kullanıcılar · İlan moderasyonu · Kategoriler · Siparişler · Ödemeler · İadeler · Satıcılar · Komisyonlar · Kampanyalar · Destek talepleri · Denetim kayıtları</p></section>
    </main>
  </div>;
}